/**
 * NBUWService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.mli.odm.webservice;

public interface NBUWService extends java.rmi.Remote {
    public void nbodmuw(java.lang.String trans_no, java.lang.String policy_no, java.lang.String service_no, java.lang.String txn_seq, java.lang.String sequence, java.lang.String business, java.lang.String channel, java.lang.String station, java.lang.String swt_opt, java.lang.String prog_type, java.lang.String batch_date, java.lang.String process_user, java.lang.String argTxnMb) throws java.rmi.RemoteException;
    public void taodmuw(java.lang.String trans_no, java.lang.String policy_no, java.lang.String service_no, java.lang.String txn_seq, java.lang.String sequence, java.lang.String business, java.lang.String channel, java.lang.String station, java.lang.String swt_opt, java.lang.String prog_type, java.lang.String batch_date, java.lang.String process_user, java.lang.String argTxnMb) throws java.rmi.RemoteException;
}
