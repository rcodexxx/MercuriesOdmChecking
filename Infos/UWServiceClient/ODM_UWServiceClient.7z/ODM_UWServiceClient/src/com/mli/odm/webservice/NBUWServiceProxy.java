package com.mli.odm.webservice;

public class NBUWServiceProxy implements com.mli.odm.webservice.NBUWService {
  private String _endpoint = null;
  private com.mli.odm.webservice.NBUWService nBUWService = null;
  
  public NBUWServiceProxy() {
    _initNBUWServiceProxy();
  }
  
  public NBUWServiceProxy(String endpoint) {
    _endpoint = endpoint;
    _initNBUWServiceProxy();
  }
  
  private void _initNBUWServiceProxy() {
    try {
      nBUWService = (new com.mli.odm.webservice.NBUWServiceServiceLocator()).getNBUWService();
      if (nBUWService != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)nBUWService)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)nBUWService)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (nBUWService != null)
      ((javax.xml.rpc.Stub)nBUWService)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.mli.odm.webservice.NBUWService getNBUWService() {
    if (nBUWService == null)
      _initNBUWServiceProxy();
    return nBUWService;
  }
  
  public void nbodmuw(java.lang.String trans_no, java.lang.String policy_no, java.lang.String service_no, java.lang.String txn_seq, java.lang.String sequence, java.lang.String business, java.lang.String channel, java.lang.String station, java.lang.String swt_opt, java.lang.String prog_type, java.lang.String batch_date, java.lang.String process_user, java.lang.String argTxnMb) throws java.rmi.RemoteException{
    if (nBUWService == null)
      _initNBUWServiceProxy();
    nBUWService.nbodmuw(trans_no, policy_no, service_no, txn_seq, sequence, business, channel, station, swt_opt, prog_type, batch_date, process_user, argTxnMb);
  }
  
  public void taodmuw(java.lang.String trans_no, java.lang.String policy_no, java.lang.String service_no, java.lang.String txn_seq, java.lang.String sequence, java.lang.String business, java.lang.String channel, java.lang.String station, java.lang.String swt_opt, java.lang.String prog_type, java.lang.String batch_date, java.lang.String process_user, java.lang.String argTxnMb) throws java.rmi.RemoteException{
    if (nBUWService == null)
      _initNBUWServiceProxy();
    nBUWService.taodmuw(trans_no, policy_no, service_no, txn_seq, sequence, business, channel, station, swt_opt, prog_type, batch_date, process_user, argTxnMb);
  }
  
  
}