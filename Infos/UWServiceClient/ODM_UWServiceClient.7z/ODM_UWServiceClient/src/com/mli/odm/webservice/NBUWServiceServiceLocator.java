/**
 * NBUWServiceServiceLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.mli.odm.webservice;

public class NBUWServiceServiceLocator extends org.apache.axis.client.Service implements com.mli.odm.webservice.NBUWServiceService {

    public NBUWServiceServiceLocator() {
    }


    public NBUWServiceServiceLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public NBUWServiceServiceLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for NBUWService
    private java.lang.String NBUWService_address = "http://localhost:12761/ODM_UWService/services/NBUWService";

    public java.lang.String getNBUWServiceAddress() {
        return NBUWService_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String NBUWServiceWSDDServiceName = "NBUWService";

    public java.lang.String getNBUWServiceWSDDServiceName() {
        return NBUWServiceWSDDServiceName;
    }

    public void setNBUWServiceWSDDServiceName(java.lang.String name) {
        NBUWServiceWSDDServiceName = name;
    }

    public com.mli.odm.webservice.NBUWService getNBUWService() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(NBUWService_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getNBUWService(endpoint);
    }

    public com.mli.odm.webservice.NBUWService getNBUWService(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            com.mli.odm.webservice.NBUWServiceSoapBindingStub _stub = new com.mli.odm.webservice.NBUWServiceSoapBindingStub(portAddress, this);
            _stub.setPortName(getNBUWServiceWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setNBUWServiceEndpointAddress(java.lang.String address) {
        NBUWService_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (com.mli.odm.webservice.NBUWService.class.isAssignableFrom(serviceEndpointInterface)) {
                com.mli.odm.webservice.NBUWServiceSoapBindingStub _stub = new com.mli.odm.webservice.NBUWServiceSoapBindingStub(new java.net.URL(NBUWService_address), this);
                _stub.setPortName(getNBUWServiceWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("NBUWService".equals(inputPortName)) {
            return getNBUWService();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://webservice.odm.mli.com", "NBUWServiceService");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://webservice.odm.mli.com", "NBUWService"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("NBUWService".equals(portName)) {
            setNBUWServiceEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
